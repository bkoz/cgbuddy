//
// File: cgbuddy.c
//
// Author: Bob Kozdemba <koz@gmail.com>
//
// Description: An example program that controls 2 cgroups directly with 
// the libcgroup API. The controller name/value pairs supported in this 
// program are:
// cpu.shares, cpuset.cpus and freezer.state
//
// Build command:
//
// gcc -o cgbuddy cgbuddy.c `pkg-config --cflags --libs gtk+-2.0` -lcgroup
//
// Usage:
//       cgbuddy [group1] [group2]
//
// The control groups must exist before cgbuddy is run.
//
// 'Last modified: Tue May 10, 2011  04:53PM CDT
//

#include <gtk/gtk.h>
#include <stdio.h>
#include <libcgroup.h>
#include <string.h>
#include <stdlib.h>

gint count = 8;
char buf[32];

int r;

//
// A structure used in widget callbacks.
//
typedef struct
{
  int id;
  GtkLabel *label;
} GroupId;

GroupId groupId[2];

struct cgroup *my_group[2];
struct cgroup *dest_group[2];
struct cgroup_controller *cpuController[2];
struct cgroup_controller *freezerController[2];
struct cgroup_controller *cpuset[2];
int64_t value;
int ncount;
int cpuShares[2];
static char freezerState[2][16];
static char freezerStates[2][16] = { "THAWED", "FROZEN" };
static char cpuSet[2][16] = { "0,1", "0,1" };

static pid_t taskPid[2];
static char cpuMems[2] = "0";

char *group1;
char *group2;

void
cgUpdate ()
{
// To change a value, set it in the temporary group/controller and
// repeat the copy and modify as above.
  cgroup_set_value_int64 (cpuController[0], "cpu.shares", cpuShares[0]);
  cgroup_set_value_int64 (cpuController[1], "cpu.shares", cpuShares[1]);
  cgroup_set_value_string (freezerController[0], "freezer.state",
			   freezerState[0]);
  cgroup_set_value_string (freezerController[1], "freezer.state",
			   freezerState[1]);
  cgroup_set_value_string (cpuset[0], "cpuset.cpus", cpuSet[0]);
  cgroup_set_value_string (cpuset[0], "cpuset.mems", cpuMems);
  cgroup_set_value_string (cpuset[1], "cpuset.cpus", cpuSet[1]);
  cgroup_set_value_string (cpuset[1], "cpuset.mems", cpuMems);

  r = cgroup_copy_cgroup (dest_group[0], my_group[0]);
  r = cgroup_copy_cgroup (dest_group[1], my_group[1]);
  if (r != 0)
    {
      fprintf (stderr, "cgroup_copy_cgroup: %s\n", cgroup_strerror (r));
    }

  r = cgroup_modify_cgroup (dest_group[0]);
  r = cgroup_modify_cgroup (dest_group[1]);
  if (r != 0)
    {
      printf ("modify_cgroup error string: %s\n", cgroup_strerror (r));
    }



}

void
cgInit ()
{

  cpuShares[0] = 2048;
  cpuShares[1] = 2048;

  r = cgroup_init ();

// Grab a pointer to the kernel's cgroup defined in /etc/cgcontrol.conf
  dest_group[0] = cgroup_new_cgroup (group1);
  dest_group[1] = cgroup_new_cgroup (group2);

// Create a temporary cgroup
  my_group[0] = cgroup_new_cgroup ("tmp0");
  my_group[1] = cgroup_new_cgroup ("tmp1");
  r = cgroup_get_cgroup (my_group[0]);
  if (r == 0)
    {
      fprintf (stderr, "cgroup_get_cgroup failed!\n");
    }
  r = cgroup_get_cgroup (my_group[1]);
  if (r == 0)
    {
      fprintf (stderr, "cgroup_get_cgroup failed!\n");
    }

// add the neccessary controllers.
  cpuController[0] = cgroup_add_controller (my_group[0], "cpu");
  cpuController[1] = cgroup_add_controller (my_group[1], "cpu");
  freezerController[0] = cgroup_add_controller (my_group[0], "freezer");
  freezerController[1] = cgroup_add_controller (my_group[1], "freezer");
  cpuset[0] = cgroup_add_controller (my_group[0], "cpuset");
  cpuset[1] = cgroup_add_controller (my_group[1], "cpuset");

// Add the name value/pairs that will be changed.
  r = cgroup_add_value_int64 (cpuController[0], "cpu.shares", cpuShares[0]);
  r = cgroup_add_value_int64 (cpuController[1], "cpu.shares", cpuShares[1]);
  if (r != 0)
    {
      fprintf (stderr, "cgroup_add_value_int64: %s\n", cgroup_strerror (r));
    }
  cgroup_add_value_string (freezerController[0], "freezer.state",
			   freezerState[0]);
  cgroup_add_value_string (freezerController[1], "freezer.state",
			   freezerState[1]);
  cgroup_add_value_string (cpuset[0], "cpuset.cpus", cpuSet[0]);
  cgroup_add_value_string (cpuset[0], "cpuset.mems", cpuMems);
  cgroup_add_value_string (cpuset[1], "cpuset.cpus", cpuSet[1]);
  cgroup_add_value_string (cpuset[1], "cpuset.mems", cpuMems);

  ncount = cgroup_get_value_name_count (cpuController[0]);

  r = cgroup_get_value_int64 (cpuController[0], "cpu.shares", &value);
// To initiate the change copy the temporary group to the kernel.
  r = cgroup_copy_cgroup (dest_group[0], my_group[0]);
  r = cgroup_copy_cgroup (dest_group[1], my_group[1]);
  if (r != 0)
    {
      fprintf (stderr, "cgroup_copy_cgroup: %s\n", cgroup_strerror (r));
    }

// and make it happen.
  r = cgroup_modify_cgroup (dest_group[0]);
  if (r != 0)
    {
      printf ("modify_cgroup error string: %s\n", cgroup_strerror (r));
    }
  r = cgroup_modify_cgroup (dest_group[1]);
  if (r != 0)
    {
      printf ("modify_cgroup error string: %s\n", cgroup_strerror (r));
    }
}

void
updateTasks (GtkWidget * widget, gpointer p)
{
  GroupId *gid = (GroupId *) p;

  taskPid[gid->id] = atoi (gtk_entry_get_text ((GtkEntry *) widget));
  sprintf (buf, "tasks=%s", gtk_entry_get_text ((GtkEntry *) widget));
  gtk_label_set_text (gid->label, buf);

  if (taskPid[gid->id] != 0)
    {
      r = cgroup_attach_task_pid (dest_group[gid->id], taskPid[gid->id]);
      if (r != 0)
	{
	  fprintf (stderr, "cgroup_attach_task_pid: %s\n",
		   cgroup_strerror (r));
	}
    }


}

void
updateCPU (GtkWidget * widget, gpointer p)
{
  GroupId *gid = (GroupId *) p;

  sprintf (cpuSet[gid->id], "%s", gtk_entry_get_text ((GtkEntry *) widget));
  sprintf (buf, "cpuset.cpus=%s", gtk_entry_get_text ((GtkEntry *) widget));
  gtk_label_set_text (gid->label, buf);
  cgUpdate ();

}

void
updateScale (GtkWidget * widget, gpointer p)
{

  GroupId *gid = (GroupId *) p;
  gint iValue = gtk_spin_button_get_value_as_int ((GtkSpinButton *) widget);
  cpuShares[gid->id] = iValue;
  sprintf (buf, "cpu.shares=%d", iValue);
  gtk_label_set_text (gid->label, buf);
  cgUpdate ();
}

void
rs (GtkWidget * widget, gpointer p)
{

  GroupId *gid = (GroupId *) p;

  strcpy (freezerState[gid->id],
	  freezerStates[gtk_toggle_button_get_active
			((GtkToggleButton *) widget)]);
  sprintf (buf, "freezer.state=%s", freezerState[gid->id]);
  gtk_label_set_text (gid->label, buf);
  cgUpdate ();
}


int
main (int argc, char **argv)
{

  GtkWidget *label[2];
  GtkWidget *window;
  GtkWidget *frame[3];
  GtkWidget *runstop[2];
  GtkWidget *spinner[2];
  GtkAdjustment *spinner_adj[2];
  GtkWidget *cpus[2];
  GtkWidget *tasks[2];
  GtkWidget *table[3];
  GtkWidget *main_table;
  GtkWidget *rowLabel[5];

  gtk_init (&argc, &argv);

  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position (GTK_WINDOW (window), GTK_WIN_POS_CENTER);
  gtk_window_set_title (GTK_WINDOW (window), "cgBuddy");
  main_table = gtk_table_new (1, 3, TRUE);
  gtk_container_add (GTK_CONTAINER (window), main_table);

  switch (argc)
    {
    case 2:
      fprintf (stderr, "cgbuddy [group1] [group2]\n");
      exit (1);
      break;

    case 3:
      group1 = argv[1];
      group2 = argv[2];
      break;

    default:
      group1 = "group1";
      group2 = "group2";
    }

  cgInit ();

  frame[2] = gtk_frame_new ("");
  frame[0] = gtk_frame_new (group1);
  frame[1] = gtk_frame_new (group2);

  table[0] = gtk_table_new (5, 3, TRUE);
  table[1] = gtk_table_new (5, 3, TRUE);
  table[2] = gtk_table_new (5, 3, TRUE);
  gtk_table_attach_defaults (GTK_TABLE (main_table), frame[2], 0, 1, 0, 1);
  gtk_table_attach_defaults (GTK_TABLE (main_table), frame[0], 1, 2, 0, 1);
  gtk_table_attach_defaults (GTK_TABLE (main_table), frame[1], 2, 3, 0, 1);
  gtk_container_add (GTK_CONTAINER (frame[0]), table[0]);
  gtk_container_add (GTK_CONTAINER (frame[1]), table[1]);
  gtk_container_add (GTK_CONTAINER (frame[2]), table[2]);

  // Build the table of labels.
  rowLabel[0] = gtk_label_new ("cpu.shares");
  gtk_table_attach_defaults (GTK_TABLE (table[2]), rowLabel[0], 0, 3, 0, 1);
  rowLabel[1] = gtk_label_new ("cpuset.cpus");
  gtk_table_attach_defaults (GTK_TABLE (table[2]), rowLabel[1], 0, 3, 1, 2);
  rowLabel[2] = gtk_label_new ("freezer.state");
  gtk_table_attach_defaults (GTK_TABLE (table[2]), rowLabel[2], 0, 3, 2, 3);
  rowLabel[3] = gtk_label_new ("tasks");
  gtk_table_attach_defaults (GTK_TABLE (table[2]), rowLabel[3], 0, 3, 3, 4);
  // rowLabel[3] = gtk_label_new ("******");
  // gtk_table_attach_defaults (GTK_TABLE (table[2]), rowLabel[3], 0, 3, 3, 4);

  spinner_adj[0] =
    (GtkAdjustment *) gtk_adjustment_new (2048.0, 2.0, 2048.0, 1.0, 1.0, 0.0);
  spinner[0] = gtk_spin_button_new (spinner_adj[0], 1.0, 0);
  spinner_adj[1] =
    (GtkAdjustment *) gtk_adjustment_new (2048.0, 2.0, 2048.0, 1.0, 1.0, 0.0);
  spinner[1] = gtk_spin_button_new (spinner_adj[1], 1.0, 0);

  gtk_table_attach_defaults (GTK_TABLE (table[0]), spinner[0], 0, 3, 0, 1);
  gtk_table_attach_defaults (GTK_TABLE (table[1]), spinner[1], 0, 3, 0, 1);

  label[0] = gtk_label_new ("");
  label[1] = gtk_label_new ("");
  gtk_table_attach_defaults (GTK_TABLE (table[0]), label[0], 0, 3, 4, 5);
  gtk_table_attach_defaults (GTK_TABLE (table[1]), label[1], 0, 3, 4, 5);

  runstop[0] = gtk_check_button_new_with_label ("Freeze");
  runstop[1] = gtk_check_button_new_with_label ("Freeze");
  gtk_table_attach_defaults (GTK_TABLE (table[0]), runstop[0], 0, 3, 2, 3);
  gtk_table_attach_defaults (GTK_TABLE (table[1]), runstop[1], 0, 3, 2, 3);

  cpus[0] = gtk_entry_new ();
  cpus[1] = gtk_entry_new ();
  gtk_table_attach_defaults (GTK_TABLE (table[0]), cpus[0], 0, 3, 1, 2);
  gtk_table_attach_defaults (GTK_TABLE (table[1]), cpus[1], 0, 3, 1, 2);
  gtk_entry_set_text ((GtkEntry *) cpus[0], "0,1");
  gtk_entry_set_text ((GtkEntry *) cpus[1], "0,1");

  // Tasks
  tasks[0] = gtk_entry_new ();
  tasks[1] = gtk_entry_new ();
  gtk_table_attach_defaults (GTK_TABLE (table[0]), tasks[0], 0, 3, 3, 4);
  gtk_table_attach_defaults (GTK_TABLE (table[1]), tasks[1], 0, 3, 3, 4);

  gtk_widget_show_all (window);

  g_signal_connect (window, "destroy", G_CALLBACK (gtk_main_quit), NULL);

  groupId[0].id = 0;
  groupId[0].label = (GtkLabel *) label[0];
  groupId[1].id = 1;
  groupId[1].label = (GtkLabel *) label[1];

  g_signal_connect (spinner[0], "value-changed", G_CALLBACK (updateScale),
		    (gpointer) & groupId[0]);
  g_signal_connect (spinner[1], "value-changed", G_CALLBACK (updateScale),
		    (gpointer) & groupId[1]);

  g_signal_connect (runstop[0], "toggled", G_CALLBACK (rs),
		    (gpointer) & groupId[0]);
  g_signal_connect (runstop[1], "toggled", G_CALLBACK (rs),
		    (gpointer) & groupId[1]);

  g_signal_connect (cpus[0], "activate", G_CALLBACK (updateCPU),
		    (gpointer) & groupId[0]);
  g_signal_connect (cpus[1], "activate", G_CALLBACK (updateCPU),
		    (gpointer) & groupId[1]);

  g_signal_connect (tasks[0], "activate", G_CALLBACK (updateTasks),
		    (gpointer) & groupId[0]);
  g_signal_connect (tasks[1], "activate", G_CALLBACK (updateTasks),
		    (gpointer) & groupId[1]);

  gtk_main ();

  return 0;
}
